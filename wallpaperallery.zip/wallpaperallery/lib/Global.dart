import 'models/photos.dart';

class Global{
  static List<Photos> photos =new List();
  static int Index=0;

}